package com.bs.aiprocessor.service;

import java.io.IOException;
import java.util.Collection;
import java.util.List;

import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;

import com.bs.aiprocessor.domain.SheetObject;

public interface ExcelService {

  Collection<SheetObject> findAllSheets(String fileName) throws IOException, EncryptedDocumentException,
      InvalidFormatException;
	
  List<String> getAllSheetNames(String fileName) throws EncryptedDocumentException, InvalidFormatException, IOException;
	
  List<String> getColumnsOfSheet(String fileName, String sheetName) throws EncryptedDocumentException,
      InvalidFormatException, IOException;

  List<String> getAllFieldsWithSheetName(String fileName) throws EncryptedDocumentException, InvalidFormatException,
      IOException;
}
