package com.bs.main;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AiprocessorApplication {

	public static void main(String[] args) {
		SpringApplication.run(AiprocessorApplication.class, args);
	}
}
