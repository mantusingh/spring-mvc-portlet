package com.bs.main;

import java.io.IOException;

import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.SpringApplicationConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import com.bs.aiprocessor.main.AiprocessorApplication;
import com.bs.aiprocessor.service.ExcelService;

@RunWith(SpringJUnit4ClassRunner.class)
@SpringApplicationConfiguration(classes = AiprocessorApplication.class)
@WebAppConfiguration
public class AiprocessorApplicationTests {
	
	@Autowired
	private ExcelService excelService;

	@Test
	public void contextLoads() {
	}
	
	@Test
	public void test() throws IOException{
		try {
			excelService.findAllSheets();
		} catch (EncryptedDocumentException | InvalidFormatException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
