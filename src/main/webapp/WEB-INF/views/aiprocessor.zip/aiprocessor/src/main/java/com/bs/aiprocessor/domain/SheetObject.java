package com.bs.aiprocessor.domain;

import java.io.Serializable;
import java.util.List;

public class SheetObject implements Serializable{

	private static final long serialVersionUID = 1L;
	
	private Long id;
	
	private String sheetName;
	
	private List<String> columnNames;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getSheetName() {
		return sheetName;
	}

	public void setSheetName(String sheetName) {
		this.sheetName = sheetName;
	}

	public List<String> getColumnNames() {
		return columnNames;
	}

	public void setColumnNames(List<String> columnNames) {
		this.columnNames = columnNames;
	}
	
	public SheetObject(){
	}

	public SheetObject(String sheetName, List<String> columnNames) {
		super();
		this.sheetName = sheetName;
		this.columnNames = columnNames;
	}

	@Override
	public String toString() {
		return "Sheet [id=" + id + ", sheetName=" + sheetName + ", columnNames=" + columnNames + "]";
	}
	
	
	
	
}
