package com.bs.aiprocessor.domain;

import java.util.List;

public class Form {
	
	private List<String> sheetNamesirst;

	public List<String> getSheetNamesirst() {
		return sheetNamesirst;
	}

	public void setSheetNamesirst(List<String> sheetNamesirst) {
		this.sheetNamesirst = sheetNamesirst;
	}

	

}
