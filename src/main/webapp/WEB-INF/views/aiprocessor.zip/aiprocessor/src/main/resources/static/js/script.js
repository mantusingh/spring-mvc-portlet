function sendAjaxRequest(){
var sheetName = $("#sheetName").val();
$.get( "/columns?sheetName=" + sheetName, function( data ) {
$("#column").empty();
    data.forEach(function(item, i) {
    var option = "<option value = " + item + ">" + item +  "</option>";
    $("#column").append(option);
    });
});
};

$(document).ready(
	    function() {
	        $("#sheetName").change(function() {
	        sendAjaxRequest();
	        });
	    }
	);