package com.bs.aiprocessor.service;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.stream.Collectors;

import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.Resource;
import org.springframework.core.io.ResourceLoader;
import org.springframework.stereotype.Component;

import com.bs.aiprocessor.domain.SheetObject;

@Component
public class ExcelServiceImpl implements ExcelService{

	@Autowired
    private ResourceLoader resourceLoader;
	
	@Override
  public Collection<SheetObject> findAllSheets(String fileName) throws IOException, EncryptedDocumentException,
      InvalidFormatException {
    Resource resource = resourceLoader.getResource("classpath:" + fileName);
		FileInputStream fis = new FileInputStream(resource.getFile());
	    Workbook workbook = WorkbookFactory.create(fis);
	    List<SheetObject> sheetObjectList=new ArrayList<>();
	    workbook.forEach(sheet-> sheetObjectList.add(getSheetObject(sheet)));
	    System.out.print(sheetObjectList.size());
		return sheetObjectList;
	}
	
	private  SheetObject  getSheetObject(Sheet excelSheet){
		SheetObject sheetObject=new SheetObject();
		List<String> columnsList=new ArrayList<>();
		excelSheet.getRow(0).forEach(cell-> columnsList.add(cell.getStringCellValue()));
		sheetObject.setSheetName(excelSheet.getSheetName());
		sheetObject.setColumnNames(columnsList);
		return sheetObject;
    }

	@Override
  public List<String> getAllSheetNames(String fileName) throws EncryptedDocumentException, InvalidFormatException,
      IOException {
    Resource resource = resourceLoader.getResource("classpath:" + fileName);
		FileInputStream fis = new FileInputStream(resource.getFile());
	    Workbook workbook = WorkbookFactory.create(fis);
	    List<String> sheetNames=new ArrayList<>();
	    workbook.forEach(sheet-> sheetNames.add(sheet.getSheetName()));
		return sheetNames;
	}

	@Override
  public List<String> getColumnsOfSheet(String fileName, String sheetName) throws EncryptedDocumentException,
      InvalidFormatException, IOException {
		
    return findAllSheets(fileName)
		.stream()
		.filter(sheet-> sheet.getSheetName()
		.equals(sheetName))
		.map(SheetObject::getColumnNames)
		.collect(Collectors.toList()).get(0);
		
	}

  @Override
  public List<String> getAllFieldsWithSheetName(String fileName) throws EncryptedDocumentException,
      InvalidFormatException, IOException {
    List<String> fieldsWithSheetName = new ArrayList<>();
    /*
     * Map<String, List<String>> sdasdad=findAllSheets(fileName) .stream()
     * .collect(Collectors.toMap(SheetObject::getSheetName, SheetObject::getColumnNames));
     * sdasdad.entrySet().iterator().
     */
    for (SheetObject sheetObject : findAllSheets(fileName)) {
      for (String string : sheetObject.getColumnNames()) {
        fieldsWithSheetName.add(sheetObject.getSheetName() + "." + string);
      }
    }
    return fieldsWithSheetName;
  }

}
